package testScenarios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import TestObjectRepository.Home_Page;
import UserDefinedlibraries.DriverSetup;
import UserDefinedlibraries.ExcelReadWrite;
import UserDefinedlibraries.ScreenShot;


public class HomeAppliances extends DriverSetup {
	
	public static XSSFWorkbook workbook ; 
    public static XSSFSheet sheet;
    public static XSSFCell cell;
	public static XSSFRow Row;
    public static String category1;
    public static String category2;
    public static String val1,val2,browser;
    public static File src;
    public static int t;
    public static List<WebElement> listofvalues,list1;
    public static WebDriver driver;    
    
    @Parameters("browser")
    @BeforeClass
    public void driverconfig(String browser)
    {
    	driver=DriverSetup.driverInstantiate(browser);   
    }
    
    @Test(priority=1)
    public void testcaseRexl() throws IOException, FileNotFoundException
    {
    	ExcelReadWrite.readexcel();    
    }
    
    @Test(priority=2)
    public static void clicksearch()
    {
    	Home_Page.searchbox(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @Test(priority=3)
    public static void enterinput()
    {
    	Home_Page.textinput(driver).sendKeys("refrigerators with freezer");
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test(priority=4)
    public static void searchtext()
    {
    	Home_Page.searchicon(driver).click();
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[1]"))));
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test(priority=5)
    public static void clickitemone() throws InterruptedException
    {
    	Thread.sleep(3000);
    	Home_Page.gridone(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='add-on-atc-container']/div[1]/section/div[1]/div[3]"))));
    }
    
    @Test(priority=6)
    public static void atcone() throws InterruptedException
    {
    	Home_Page.addtocart(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Thread.sleep(5000);
    	driver.navigate().back();
    	driver.navigate().back();
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[2]"))));
    }
    
    @Test(priority=7)
    public static void clickitemtwo() throws InterruptedException
    {
    	Thread.sleep(5000);
    	Home_Page.gridtwo(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='add-on-atc-container']/div[1]/section/div[1]/div[3]"))));
    	
    }
    
    @Test(priority=8)
    public static void atctwo() throws InterruptedException
    {
    	Home_Page.addtocart(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='cart-root-container-content-skip']/div[1]/div/div[2]/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[2]/div/button[1]"))));
    }
    
    
    
    @Test(priority=9)
    public static void checkout() throws InterruptedException
    {
    	Thread.sleep(5000);
    	Home_Page.checkout(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[1]/div[3]/div/div/div/div[5]/div/div/div/div[2]/div/div/div[1]/div[4]/div[2]/span[2]"))));
    	//*[@id='cart-root-container-content-skip']/div[1]/div/div[2]/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[2]/div/button[1]
    }
    
    @Test(priority=10)
    public static void getprice() throws InterruptedException
    {
    	Thread.sleep(5000);
    	val1 =  Home_Page.price(driver).getText();
  	    System.out.println("output of two items "+ val1);
  	  try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test(priority=11)
    public void typeExcelOne(){
        t = ExcelReadWrite.row;
        cell = ExcelReadWrite.sheet.getRow(t).getCell(1);
   	  if (cell== null)
   		  cell = ExcelReadWrite.sheet.getRow(t).createCell(1);
   	  cell.setCellValue(val1);
   	  ExcelReadWrite.writeexcel();	
    }
    
    @Test(priority=12)
    public static void clickitemthree() throws InterruptedException
    {
    	driver.navigate().back();
    	driver.navigate().back();
    	driver.navigate().back();
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[3]"))));
    	Thread.sleep(5000);
    	Home_Page.gridthree(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='add-on-atc-container']/div[1]/section/div[1]/div[3]"))));
    }
    
    @Test(priority=13)
    public static void atcthree() throws InterruptedException
    {
    	Thread.sleep(5000);
    	Home_Page.addtocart(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='cart-root-container-content-skip']/div[1]/div/div[2]/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[2]/div/button[1]"))));
    	
    	
    }
    
    @Test(priority=14)
    public static void checkouttwo() throws InterruptedException
    {
    	Thread.sleep(5000);
    	Home_Page.checkout(driver).click();
    	try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebDriverWait wait = new WebDriverWait(driver,30);
    	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[1]/div[3]/div/div/div/div[5]/div/div/div/div[2]/div/div/div[1]/div[4]/div[2]/span[2]"))));
    }
    
    @Test(priority=15)
    public static void getpricetwo() throws InterruptedException
    {
    	Thread.sleep(5000);
    	val2 =  Home_Page.price(driver).getText();
  	    System.out.println("output of three items "+ val2);
  	  try {
			ScreenShot.screenShotTC(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test(priority=16)
    public void typeExceltwo(){
        t = ExcelReadWrite.row;
        cell = ExcelReadWrite.sheet.getRow(t).getCell(2);
   	  if (cell== null)
   		  cell = ExcelReadWrite.sheet.getRow(t).createCell(2);
   	  cell.setCellValue(val2);
   	  ExcelReadWrite.writeexcel();	
    }
    @Test(priority=17)
    public static void screenshot()throws IOException
    {
	    ScreenShot.screenShotTC(driver);	  
    }
	  
    @AfterClass
    public void driverexit()
    {
    	DriverSetup.driverClose();    
    }  

}
