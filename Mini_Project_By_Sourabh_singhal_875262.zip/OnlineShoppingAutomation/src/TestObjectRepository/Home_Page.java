package TestObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Home_Page {
public static WebElement element = null;
public static WebDriver driver;
     
    public static WebElement price(WebDriver driver) {
    	element =driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div[1]/div[3]/div/div/div/div[5]/div/div/div/div[2]/div/div/div[1]/div[4]/div[2]/span[2]"));
    	return element;
    }
    
    public static WebElement checkout(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='cart-root-container-content-skip']/div[1]/div/div[2]/div/div/div/div/div[3]/div/div/div[2]/div[1]/div[2]/div/button[1]"));
    	return element;
    }
    
    public static WebElement gridone(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[1]"));
    	return element;
    }  
    public static WebElement gridtwo(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[2]"));
    	return element;
    }  
    public static WebElement gridthree(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='searchProductResult']/ul/li[3]"));
    	return element;
    }  
    
    public static WebElement homelogo(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='hf-home-link']"));
    	return element;
    }
    
    public static WebElement searchbox(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='global-search-input']"));
    	return element;
    }
    
    public static WebElement searchicon(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='global-search-submit']/span"));
    	return element;
    }  
    public static WebElement textinput(WebDriver driver) {
    	element=driver.findElement(By.id("global-search-input"));
    	return element;
    } 
    public static WebElement addtocart(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='add-on-atc-container']/div[1]/section/div[1]/div[3]"));
    	return element;
    }
    public static WebElement viewcart(WebDriver driver) {
    	element =driver.findElement(By.xpath("//*[@id='header-bubble-links']/div[3]"));
    	return element;
    }
  
}
