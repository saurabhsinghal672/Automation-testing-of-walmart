About this project

Website used: www.walmart.com

Requirements:

Firefox version : 64
Chrome version : 85 and above

OS: Windows 10

Eclipse IDE : Luna

This project has two main classes: Home_Page.java and Home_Appliances.java

Home_Page.java has all the global functions declared to complete this project
Location : C:\Users\ace\OnlineShoppingAutomation\src\TestObjectRepository\Home_Page.java

Home_Appliances.java has the main code that runs the code 
Location : C:\Users\ace\OnlineShoppingAutomation\src\testScenarios\HomeAppliances.java

This project has driversetup file where drivers are declared.
Location : C:\Users\ace\OnlineShoppingAutomation\src\UserDefinedlibraries\DriverSetup.java

This project has excelreadwrite file where excel read and write is done.
Location : C:\Users\ace\OnlineShoppingAutomation\src\UserDefinedlibraries\ExcelReadWrite.java

This project has screenshot.java file where code for taking screenshot is written.
Location : C:\Users\ace\OnlineShoppingAutomation\src\UserDefinedlibraries\ScreenShot.java

Excel file after writing the value
Location : /OnlineShoppingAutomation/src/Datatables/onlineshopping.xlsx

***Warning***
Walmart sometimes ask you to identify your identity.
In that case you should verify yourself or re run the code.

Steps:

1. Navigate to https://www.walmart.com/ website and take screenshot

2. Click the search item box and take screenshot

3. Enter "refrigerator with freezer" as it is also a home appliance, click on search icon and take screenshot

4. click on item one , add it to the cart and take screenshot

5. Click on item two , add it to the cart and take screenshot

6. go to cart and click on checkout and fetch the price of two items in the cart , store it in excel and take screenshot

7. Go back and add third item to the cart and take screenshot

8. go to cart and click on checkout and fetch the price of three items in the cart, store it in excel and take screenshot

9. Close the opened browser


Output in Chrome:

output of two items $441.43
output of three items $590.43

***output can change as product can change at any time

Output in Firefox:

output of two items $441.43
output of three items $590.43

***output can change as product can change at any time


